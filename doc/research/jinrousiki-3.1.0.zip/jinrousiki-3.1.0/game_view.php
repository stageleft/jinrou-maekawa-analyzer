<?php
require_once('init.php');
Loader::LoadFile('game_view_class');
GameView::Execute();
