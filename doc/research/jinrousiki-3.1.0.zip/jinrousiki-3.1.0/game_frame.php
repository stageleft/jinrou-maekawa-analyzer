<?php
require_once('init.php');
Loader::LoadFile('game_frame_class');
GameFrame::Execute();
