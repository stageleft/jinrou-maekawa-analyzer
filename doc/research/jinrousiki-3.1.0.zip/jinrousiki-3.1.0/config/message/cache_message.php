<?php
//-- JinrouCache 専用メッセージ --//
class CacheMessage {
  /* 更新情報 */
  const RELOAD = '次回キャッシュ更新時刻：';
  const RELOAD_TALK_VIEW = 'シーン変更でリセットされます';
  const RELOAD_TALK_PLAY = 'シーン変更・発言更新でリセットされます';
}
