<?php
//-- GameOptionInfo 専用メッセージ --//
class GameOptionInfoMessage {
  const TITLE = 'ゲームオプション';

  const ADD_ROLE		= ' (村の人口が%d人以上)';
  const REPLACE_ROLE_HEADER	= 'は管理人がカスタムすることを前提にしたオプションです';
  const REPLACE_ROLE_FOOTER	= '現在の初期設定は全員%sになります';
  const FESTIVAL_DELIMITER	= '人：';
}
