<?php
//-- SharedRoomInfo 専用メッセージ --//
class SharedRoomInfoMessage {
  const TITLE = '関連サーバ村情報';
}
