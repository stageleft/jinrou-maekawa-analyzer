<?php
//-- SearchRoleInfo 専用メッセージ --//
class SearchRoleInfoMessage {
  const TITLE = '検索';
}
