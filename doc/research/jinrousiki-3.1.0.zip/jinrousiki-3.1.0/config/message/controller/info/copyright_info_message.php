<?php
//-- CopyrightInfo 専用メッセージ --//
class CopyrightInfoMessage {
  const TITLE	= '謝辞・素材';
  const PACKAGE	= 'パッケージ情報';
}
