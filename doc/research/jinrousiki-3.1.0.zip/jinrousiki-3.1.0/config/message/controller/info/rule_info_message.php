<?php
//-- RuleInfo 専用メッセージ --//
class RuleInfoMessage {
  const TITLE = 'ルール';
}
