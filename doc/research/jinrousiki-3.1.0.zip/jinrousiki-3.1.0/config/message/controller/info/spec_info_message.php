<?php
//-- SpecInfo 専用メッセージ --//
class SpecInfoMessage {
  const TITLE = '詳細な仕様';
}
