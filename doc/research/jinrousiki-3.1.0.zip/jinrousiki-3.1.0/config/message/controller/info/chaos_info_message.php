<?php
//-- ChaosInfo 専用メッセージ --//
class ChaosInfoMessage {
  const TITLE = '闇鍋モード';
}
