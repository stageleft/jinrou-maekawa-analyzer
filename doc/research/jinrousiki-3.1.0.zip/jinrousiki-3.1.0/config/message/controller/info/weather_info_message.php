<?php
//-- WeatherInfo 専用メッセージ --//
class WeatherInfoMessage {
  const TITLE = '天候システム';
}
