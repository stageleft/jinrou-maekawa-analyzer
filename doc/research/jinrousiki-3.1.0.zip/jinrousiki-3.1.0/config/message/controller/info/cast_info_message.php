<?php
//-- CastInfo 専用メッセージ --//
class CastInfoMessage {
  const TITLE = '配役一覧';
}
