<?php
//-- ScriptInfo 専用メッセージ --//
class ScriptInfoMessage {
  const TITLE = '仕様';

  const DOT	= '・';
  const HUMAN	= '人';

  const MAX_USER_HEADER = '[ %s ] のどれかを村に登録できる村人の最大人数として設定することができます。';
  const MAX_USER_FOOTER = 'ただしゲームを開始するには最低 [ %d人 ] の村人が必要です。';
}
