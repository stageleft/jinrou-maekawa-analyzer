<?php
//-- TOP ページ専用メッセージ --//
class TopPageMessage {
  /* タイトル */
  const TITLE = '汝は人狼なりや？';
  const CAUTION_JAVASCRIPT = '&lt;&lt; JavaScriptを有効にしてください &gt;&gt;';

  /* メニュー */
  const MENU_COMMUNICATION = '交流用サイト';
  const MENU_OUTER         = '外部リンク';

  /* メイン情報 */
  const INFORMATION = 'Information <a href="info/history/top.php">～過去のinformationはこちら～</a>';
  const GAME_LIST   = 'ゲーム一覧';
  const BBS_TITLE   = '<a href="%s%sl50">告知スレッド情報</a>';
  const CREATE_ROOM = '村の作成';
}
