<?php
//-- 投票テスト専用メッセージ --//
class VoteTestMessage {
  const TITLE = '投票テスト';

  /* 配役情報 */
  const CAST_POPULATION = '人口';

  /* 能力発動結果 */
  const ABILITY_HEADER			= '前日の夜、';
  const ABILITY_TARGET			= 'は ';
  const ABILITY_MAGE_DO			= 'を占いました';
  const ABILITY_VOODOO_KILLER_DO	= 'の呪いを祓いました';
  const ABILITY_ANTI_VOODOO_DO		= 'の厄を祓いました';
  const ABILITY_MIND_SCANNER_DO		= 'の心を読みました';
  const ABILITY_JAMMER_DO		= 'の占いを妨害しました';
  const ABILITY_VOODOO_DO		= 'に呪いをかけました';
  const ABILITY_MANIA_DO		= 'を真似しました';
  const ABILITY_TARGETED		= 'を狙いました';
}
