<?php
//-- 裏・闇鍋モード配役テスト専用メッセージ --//
//-- ◆文字化け抑制◆ --//
class ChaosVersoTestMessage {
  const TITLE = '裏・闇鍋モード配役テスト';
}
