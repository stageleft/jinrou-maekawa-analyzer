<?php
//-- トリップテスト専用メッセージ --//
class TripTestMessage {
  const TITLE  = 'トリップテスト';
  const KEY    = 'トリップキー';
  const RESULT = '変換結果';
}
