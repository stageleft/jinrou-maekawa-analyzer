<?php
//-- 村配役テスト専用メッセージ --//
class CastTestMessage {
  const TITLE = '配役テスト';
}
