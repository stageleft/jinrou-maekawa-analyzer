<?php
//-- 役職名表示テスト専用メッセージ --//
//-- ◆文字化け抑制◆ --//
class NameTestMessage {
  const TITLE = '役職名表示';
}
