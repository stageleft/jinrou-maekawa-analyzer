<?php
//-- テストページ専用メッセージ --//
//-- ◆文字化け抑制◆ --//
class TestMessage {
  /* フォーム */
  const ROLE_USER	= '人数';
  const ROLE_COUNT	= '試行回数';
}
