<?php
//-- JinrouTwitter 専用メッセージ --//
class TwitterMessage {
  /* ステータス */
  const SUCCESS	= 'Twitter 投稿成功';
  const FAILED	= 'Twitter への投稿に失敗しました。';

  /* テスト用 */
  const TITLE	= 'Twitter 投稿テスト';
  const NAME	= '村名';
  const COMMENT	= 'コメント';
}
