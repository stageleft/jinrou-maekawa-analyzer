<?php
//-- 過去ログ表示設定 --//
class OldLogConfig {
  const VIEW    = 20;		//一画面に表示する村の数
  const PAGE    =  5;		//一画面に表示するページ数の数
  const REVERSE = true;		//デフォルトの村番号の表示順 (true:逆にする / false:しない)
}
