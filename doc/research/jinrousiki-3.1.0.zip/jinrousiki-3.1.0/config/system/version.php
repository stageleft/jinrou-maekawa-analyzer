<?php
class ScriptInfo {
  //パッケージのバージョン
  const VERSION = 'Ver. 3.1.0';

  //パッケージの最終更新日
  const LAST_UPDATE = '2017/12/29 (Fri) 13:05';

  //パッケージ化した時の Revision
  const REVISION = 2055;

  //パッケージ名
  const PACKAGE = '<a href="http://osdn.jp/projects/jinrousiki/">人狼式</a>';

  //開発チーム名
  const DEVELOPER = '<a href="http://osdn.jp/projects/jinrousiki/">式神研究同好会</a>';
}
