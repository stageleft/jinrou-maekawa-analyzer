<?php
require_once('init.php');
Loader::LoadFile('icon_edit_class');
IconEdit::Execute();
