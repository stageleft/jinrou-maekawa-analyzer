<?php
define('JINROU_ROOT', '../..');
require_once(JINROU_ROOT . '/include/init.php');
