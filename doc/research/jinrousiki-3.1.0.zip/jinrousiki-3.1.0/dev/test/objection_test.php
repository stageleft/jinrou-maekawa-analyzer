<?php
require_once('init.php');
Loader::LoadFile('objection_test_class');
ObjectionTest::Execute();
