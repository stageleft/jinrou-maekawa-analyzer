<?php
require_once('init.php');
Loader::LoadFile('user_entry_test_class');
UserEntryTest::Execute();
