<?php
require_once('init.php');
Loader::LoadFile('chaos_verso_test_class');
ChaosVersoTest::Execute();
