<?php
require_once('init.php');
Loader::LoadFile('cast_test_class');
CastTest::Execute();
