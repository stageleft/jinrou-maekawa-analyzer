<?php
require_once('init.php');
Loader::LoadFile('name_test_class');
NameTest::Execute();
