<?php
require_once('init.php');
Loader::LoadFile('trip_test_class');
TripTest::Execute();
