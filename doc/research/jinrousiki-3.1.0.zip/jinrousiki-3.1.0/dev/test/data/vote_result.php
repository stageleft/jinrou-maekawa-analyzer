<?php
//-- ◆文字化け抑制◆ --//
//Text::p(RQ::GetTest()->system_message, '◆System');
//Text::p(RQ::GetTest()->result_ability, '◆Ability');
//Text::p(RQ::GetTest()->result_dead,    '◆Dead');
