<?php
//Text::p(RQ::GetTest()->test_users[22], '��CastLoad');
#CastConfig::$decide = 11;
#RQ::GetTest()->test_users[3]->live = UserLive::KICK;
