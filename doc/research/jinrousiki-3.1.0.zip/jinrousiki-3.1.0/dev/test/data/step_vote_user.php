<?php
//-- ◆文字化け抑制◆ --//
RQ::GetTest()->test_users[1]->role = 'resurrect_mania';
RQ::GetTest()->test_users[1]->live = UserLive::DEAD;

RQ::GetTest()->test_users[2]->role = 'step_wolf authority';
RQ::GetTest()->test_users[2]->live = UserLive::LIVE;

RQ::GetTest()->test_users[3]->role = 'possessed_wolf possessed_target[3-17]';
RQ::GetTest()->test_users[3]->live = UserLive::LIVE;

RQ::GetTest()->test_users[4]->role = 'step_mage lovers[16] challenge_lovers rebel';
RQ::GetTest()->test_users[4]->live = UserLive::LIVE;

RQ::GetTest()->test_users[5]->role = 'soul_mage febris[6]';
RQ::GetTest()->test_users[5]->live = UserLive::LIVE;

RQ::GetTest()->test_users[6]->role = 'eclipse_medium mind_friend[21] possessed[4-15]';
RQ::GetTest()->test_users[6]->live = UserLive::DEAD;

RQ::GetTest()->test_users[7]->role = 'step_guard lovers[16]';
RQ::GetTest()->test_users[7]->live = UserLive::LIVE;

RQ::GetTest()->test_users[8]->role = 'poison_guard';
RQ::GetTest()->test_users[8]->live = UserLive::DEAD;

RQ::GetTest()->test_users[9]->role = 'missfire_cat joker[2]';
RQ::GetTest()->test_users[9]->live = UserLive::LIVE;

RQ::GetTest()->test_users[10]->role = 'ascetic_assassin death_note[5] speaker';
RQ::GetTest()->test_users[10]->live = UserLive::LIVE;

RQ::GetTest()->test_users[11]->role = 'fox downer_luck changed_vindictive';
RQ::GetTest()->test_users[11]->live = UserLive::LIVE;

RQ::GetTest()->test_users[12]->role = 'anti_voodoo death_selected[5]';
RQ::GetTest()->test_users[12]->live = UserLive::LIVE;

RQ::GetTest()->test_users[13]->role = 'step_mad';
RQ::GetTest()->test_users[13]->live = UserLive::LIVE;

RQ::GetTest()->test_users[14]->role = 'purple_fox death_warrant[6]';
RQ::GetTest()->test_users[14]->live = UserLive::LIVE;

RQ::GetTest()->test_users[15]->role = 'possessed_fox possessed_target[4-6] lost_ability';
RQ::GetTest()->test_users[15]->live = UserLive::LIVE;

RQ::GetTest()->test_users[16]->role = 'sweet_fairy lovers[16] challenge_lovers';
RQ::GetTest()->test_users[16]->live = UserLive::LIVE;

RQ::GetTest()->test_users[17]->role = 'psycho_necromancer possessed[3-3] disfavor';
RQ::GetTest()->test_users[17]->live = UserLive::DEAD;

RQ::GetTest()->test_users[18]->role = 'step_mage';
RQ::GetTest()->test_users[18]->live = UserLive::LIVE;

RQ::GetTest()->test_users[19]->role = 'shadow_fairy psycho_infected';
RQ::GetTest()->test_users[19]->live = UserLive::LIVE;

RQ::GetTest()->test_users[20]->role = 'passion_vampire';
RQ::GetTest()->test_users[20]->live = UserLive::LIVE;

RQ::GetTest()->test_users[21]->role = 'revive_mania[6] mind_friend[21]';
RQ::GetTest()->test_users[21]->live = UserLive::LIVE;

RQ::GetTest()->test_users[22]->role = 'divine_escaper reduce_voter';
RQ::GetTest()->test_users[22]->live = UserLive::LIVE;

RQ::GetTest()->test_users[23]->role = 'mad deep_sleep';
RQ::GetTest()->test_users[23]->live = UserLive::LIVE;

RQ::GetTest()->test_users[24]->role = 'barrier_wizard infected[20]';
RQ::GetTest()->test_users[24]->live = UserLive::LIVE;

RQ::GetTest()->test_users[25]->role = 'vajra_yaksa disfavor';
RQ::GetTest()->test_users[25]->live = UserLive::LIVE;
RQ::GetTest()->test_users[25]->profile = "あーうー\nうーあー";
