<?php
//-- ◆文字化け抑制◆ --//
RQ::GetTest()->test_users[1]->role = 'harp_mania';
RQ::GetTest()->test_users[1]->live = UserLive::DEAD;

RQ::GetTest()->test_users[2]->role = 'thorn_wolf authority';
RQ::GetTest()->test_users[2]->live = UserLive::LIVE;

RQ::GetTest()->test_users[3]->role = 'possessed_wolf possessed_target[3-17]';
RQ::GetTest()->test_users[3]->live = UserLive::LIVE;

RQ::GetTest()->test_users[4]->role = 'soul_mage lovers[16] challenge_lovers rebel';
RQ::GetTest()->test_users[4]->live = UserLive::LIVE;

RQ::GetTest()->test_users[5]->role = 'mage febris[6]';
RQ::GetTest()->test_users[5]->live = UserLive::LIVE;

RQ::GetTest()->test_users[6]->role = 'eclipse_medium possessed[4-15] frostbite[7]';
RQ::GetTest()->test_users[6]->live = UserLive::DEAD;

RQ::GetTest()->test_users[7]->role = 'doll lovers[13] vega_lovers';
RQ::GetTest()->test_users[7]->live = UserLive::LIVE;

RQ::GetTest()->test_users[8]->role = 'anti_voodoo';
RQ::GetTest()->test_users[8]->live = UserLive::LIVE;

RQ::GetTest()->test_users[9]->role = 'revive_fox joker[2] lovers[14] letter_exchange[4]';
RQ::GetTest()->test_users[9]->live = UserLive::LIVE;

RQ::GetTest()->test_users[10]->role = 'step_assassin death_note[5] speaker';
RQ::GetTest()->test_users[10]->live = UserLive::LIVE;

RQ::GetTest()->test_users[11]->role = 'sacrifice_depraver downer_luck';
RQ::GetTest()->test_users[11]->live = UserLive::LIVE;

RQ::GetTest()->test_users[12]->role = 'weather_priest death_selected[9]';
RQ::GetTest()->test_users[12]->live = UserLive::LIVE;

RQ::GetTest()->test_users[13]->role = 'nephila_cupid lady lovers[13] mind_receiver[9] mind_receiver[19]';
RQ::GetTest()->test_users[13]->live = UserLive::LIVE;

RQ::GetTest()->test_users[14]->role = 'letter_cupid lovers[14] letter_exchange[1]';
RQ::GetTest()->test_users[14]->live = UserLive::LIVE;

RQ::GetTest()->test_users[15]->role = 'possessed_mad possessed_target[4-6] lost_ability';
RQ::GetTest()->test_users[15]->live = UserLive::LIVE;

RQ::GetTest()->test_users[16]->role = 'moon_cupid lovers[16] challenge_lovers mind_receiver[4]';
RQ::GetTest()->test_users[16]->live = UserLive::LIVE;

RQ::GetTest()->test_users[17]->role = 'critical_common possessed[3-3] disfavor';
RQ::GetTest()->test_users[17]->live = UserLive::DEAD;

RQ::GetTest()->test_users[18]->role = 'wolf no_last_words';
RQ::GetTest()->test_users[18]->live = UserLive::DEAD;

RQ::GetTest()->test_users[19]->role = 'barrier_wizard psycho_infected fake_lovers[13]';
RQ::GetTest()->test_users[19]->live = UserLive::LIVE;

RQ::GetTest()->test_users[20]->role = 'follow_vampire downer_luck';
RQ::GetTest()->test_users[20]->live = UserLive::LIVE;

RQ::GetTest()->test_users[21]->role = 'soul_mania[13] mind_friend[21]';
RQ::GetTest()->test_users[21]->live = UserLive::LIVE;

RQ::GetTest()->test_users[22]->role = 'spy_mad';
RQ::GetTest()->test_users[22]->live = UserLive::LIVE;

RQ::GetTest()->test_users[23]->role = 'meteor_tengu earplug death_selected[8]';
RQ::GetTest()->test_users[23]->live = UserLive::LIVE;

RQ::GetTest()->test_users[24]->role = 'esper_wizard mind_friend[27]';
RQ::GetTest()->test_users[24]->live = UserLive::LIVE;

RQ::GetTest()->test_users[25]->role = 'collector_ogre disfavor';
RQ::GetTest()->test_users[25]->live = UserLive::LIVE;
RQ::GetTest()->test_users[25]->profile = "あーうー\nうーあー";

RQ::GetTest()->test_users[26]->role = 'trick_mania';
RQ::GetTest()->test_users[26]->live = UserLive::LIVE;

RQ::GetTest()->test_users[27]->role = 'revive_mania[24] mind_friend[27] penetration';
RQ::GetTest()->test_users[27]->live = UserLive::LIVE;

RQ::GetTest()->test_users[28]->role = 'doom_cat bad_luck';
RQ::GetTest()->test_users[28]->live = UserLive::LIVE;

RQ::GetTest()->test_users[29]->role = 'involve_tengu mind_friend[29]';
RQ::GetTest()->test_users[29]->live = UserLive::LIVE;

RQ::GetTest()->test_users[30]->role = 'chill_fairy';
RQ::GetTest()->test_users[30]->live = UserLive::LIVE;
