<?php
#DB::$USER->ByID(9)->live = UserLive::LIVE;
DB::LoadDummyBoy();
#DB::LoadSelf(24);
//DB::$SELF = DB::$USER->TraceExchange(14);
