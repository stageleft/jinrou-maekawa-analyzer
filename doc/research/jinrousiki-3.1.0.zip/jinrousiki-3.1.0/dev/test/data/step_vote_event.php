<?php
RQ::GetTest()->system_message = array(
  4 => array(EventType::WEATHER => array(44)),
  8 => array(EventType::WEATHER => array(33))
);
