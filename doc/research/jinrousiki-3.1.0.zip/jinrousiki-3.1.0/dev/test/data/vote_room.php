<?php
class VoteTestRoom {
  const DATE = 5;
  #const SCENE = RoomScene::BEFORE;
  #const SCENE = RoomScene::DAY;
  const SCENE = RoomScene::NIGHT;
  #const SCENE = RoomScene::AFTER;
  const TIME = false;
  const DUEL = false;
  const WINNER = 'wolf';
}
