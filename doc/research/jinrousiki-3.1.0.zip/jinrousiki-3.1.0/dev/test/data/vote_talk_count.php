<?php
RQ::GetTest()->talk_count[24] = 0;
unset(RQ::GetTest()->talk_count[3]);
//unset(RQ::GetTest()->talk_count[22]);
