<?php
RQ::GetTest()->system_message = array(
  3 => array(
    #EventType::WEATHER		=> array(54),
    #EventType::VOTE_DUEL	=> array(8)
  ),
  4 => array(
    #EventType::WEATHER		=> array(49),
    EventType::EVENT		=> array('blinder'),
  ),
  5 => array(
    EventType::WEATHER		=> array(69)
  ),
  7 => array(
    #EventType::WEATHER		=> array(19)
  )
);
