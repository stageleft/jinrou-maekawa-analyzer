<?php
//RQ::Get()->say = "<<占いCO！\n赤は村人！今日は木曜日ですよwww？>>";
//RQ::Get()->font_type = TalkVoice::WEAK; TalkVoice::NORMAL;
