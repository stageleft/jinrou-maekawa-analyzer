<?php
/*
  ◆天候：宵闇 (blinder)
  ○仕様
  ・イベント仮想役職：目隠し (昼限定)
  ・極光経由の付与あり
*/
EventLoader::LoadFile('grassy');
class Event_blinder extends Event_grassy {
}
