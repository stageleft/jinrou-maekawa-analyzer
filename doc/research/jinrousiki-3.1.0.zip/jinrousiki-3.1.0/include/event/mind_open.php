<?php
/*
  ◆天候：白夜 (mind_open)
  ○仕様
  ・イベント仮想役職：公開者
  ・極光経由の付与あり
*/
EventLoader::LoadFile('grassy');
class Event_mind_open extends Event_grassy {
}
