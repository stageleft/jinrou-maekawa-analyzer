<?php
/*
  ◆天候：花吹雪 (flower_fairy)
  ○仕様
  ・悪戯 (妖精)：花妖精
*/
EventLoader::LoadFile('star_fairy');
class Event_flower_fairy extends Event_star_fairy {
}
