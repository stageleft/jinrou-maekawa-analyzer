<?php
/*
  ◆天候：春時雨 (deep_sleep)
  ○仕様
  ・イベント仮想役職：爆睡者
*/
EventLoader::LoadFile('grassy');
class Event_deep_sleep extends Event_grassy {
}
