<?php
/*
  ◆天候：流星群 (sweet_ringing)
  ○仕様
  ・イベント仮想役職：恋耳鳴
*/
EventLoader::LoadFile('grassy');
class Event_sweet_ringing extends Event_grassy {
}
