<?php
/*
  ◆悪戯：迷彩 (月妖精) (earplug)
  ○仕様
  ・イベント仮想役職：耳栓 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_earplug extends Event_grassy {
}
