<?php
/*
  ◆天候：波風 (whisper_ringing)
  ○仕様
  ・イベント仮想役職：囁耳鳴
*/
EventLoader::LoadFile('grassy');
class Event_whisper_ringing extends Event_grassy {
}
