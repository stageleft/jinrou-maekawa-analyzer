<?php
/*
  ◆天候：小夜嵐 (howl_ringing)
  ○仕様
  ・イベント仮想役職：吠耳鳴
*/
EventLoader::LoadFile('grassy');
class Event_howl_ringing extends Event_grassy {
}
