<?php
/*
  ◆天候：ダイヤモンドダスト (side_reverse)
  ○仕様
  ・イベント仮想役職：鏡面迷彩 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_side_reverse extends Event_grassy {
}
