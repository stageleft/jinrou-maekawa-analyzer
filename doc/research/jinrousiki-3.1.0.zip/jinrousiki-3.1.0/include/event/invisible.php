<?php
/*
  ◆天候：黄砂 (invisible)
  ○仕様
  ・イベント仮想役職：光学迷彩 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_invisible extends Event_grassy {
}
