<?php
/*
  ◆天候：月虹 (confession)
  ○仕様
  ・イベント仮想役職：告白 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_confession extends Event_grassy {
}
