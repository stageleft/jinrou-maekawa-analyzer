<?php
/*
  ◆天候：時化 (strong_voice)
  ○仕様
  ・イベント仮想役職：大声
*/
EventLoader::LoadFile('grassy');
class Event_strong_voice extends Event_grassy {
}
