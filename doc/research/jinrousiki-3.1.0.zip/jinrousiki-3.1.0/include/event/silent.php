<?php
/*
  ◆天候：木漏れ日 (silent)
  ○仕様
  ・イベント仮想役職：無口 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_silent extends Event_grassy {
}
