<?php
/*
  ◆天候：涙雨 (no_last_words)
  ○仕様
  ・イベント仮想役職：筆不精
*/
EventLoader::LoadFile('grassy');
class Event_no_last_words extends Event_grassy {
}
