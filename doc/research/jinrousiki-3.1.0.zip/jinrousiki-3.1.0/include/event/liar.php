<?php
/*
  ◆天候：宵月 (liar)
  ○仕様
  ・イベント仮想役職：狼少年
*/
EventLoader::LoadFile('grassy');
class Event_liar extends Event_grassy {
}
