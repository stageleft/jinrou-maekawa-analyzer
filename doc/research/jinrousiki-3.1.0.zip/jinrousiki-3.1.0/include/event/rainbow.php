<?php
/*
  ◆天候：虹 (rainbow)
  ○仕様
  ・イベント仮想役職：虹色迷彩 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_rainbow extends Event_grassy {
}
