<?php
/*
  ◆天候：細雪 (weak_voice)
  ○仕様
  ・イベント仮想役職：小声
*/
EventLoader::LoadFile('grassy');
class Event_weak_voice extends Event_grassy {
}
