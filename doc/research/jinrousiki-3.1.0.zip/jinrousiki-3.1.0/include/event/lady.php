<?php
/*
  ◆天候：桜吹雪 (lady)
  ○仕様
  ・イベント仮想役職：淑女
*/
EventLoader::LoadFile('grassy');
class Event_lady extends Event_grassy {
}
