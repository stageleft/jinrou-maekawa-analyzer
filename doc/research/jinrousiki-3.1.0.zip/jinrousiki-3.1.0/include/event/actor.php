<?php
/*
  ◆天候：スポットライト (actor)
  ○仕様
  ・イベント仮想役職：役者 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_actor extends Event_grassy {
}
