<?php
/*
  ◆天候：バナナの皮 (line_reverse)
  ○仕様
  ・イベント仮想役職：天地迷彩 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_line_reverse extends Event_grassy {
}
