<?php
/*
  ◆天候：箒星 (passion)
  ○仕様
  ・イベント仮想役職：恋色迷彩 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_passion extends Event_grassy {
}
