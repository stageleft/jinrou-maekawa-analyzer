<?php
/*
  ◆天候：春一番 (gentleman)
  ○仕様
  ・イベント仮想役職：紳士
*/
EventLoader::LoadFile('grassy');
class Event_gentleman extends Event_grassy {
}
