<?php
/*
  ◆天候：タライ (critical_luck)
  ○仕様
  ・イベント仮想役職：痛恨 (昼限定)
*/
EventLoader::LoadFile('grassy');
class Event_critical_luck extends Event_grassy {
}
