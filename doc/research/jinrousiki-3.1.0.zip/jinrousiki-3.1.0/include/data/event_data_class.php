<?php
//-- 定数リスト (Event/Type) --//
class EventType {
  const WEATHER   = 'WEATHER';
  const EVENT     = 'EVENT';
  const VOTE_DUEL = 'VOTE_DUEL';
  const SAME_FACE = 'SAME_FACE';
}
