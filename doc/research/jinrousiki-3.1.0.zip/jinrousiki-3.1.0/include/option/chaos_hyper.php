<?php
/*
  ◆超・闇鍋モード (chaos_hyper)
*/
OptionLoader::LoadFile('chaos');
class Option_chaos_hyper extends Option_chaos {
  public function GetCaption() {
    return '超・闇鍋モード';
  }
}
