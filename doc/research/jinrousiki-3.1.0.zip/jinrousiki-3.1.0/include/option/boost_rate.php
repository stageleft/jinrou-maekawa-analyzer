<?php
/*
  ◆出現率変動モード (boost_rate)
*/
OptionLoader::LoadFile('topping');
class Option_boost_rate extends Option_topping {
  public function GetCaption() {
    return '出現率変動モード';
  }

  public function GetExplain() {
    return '役職の出現率に補正がかかります';
  }
}
