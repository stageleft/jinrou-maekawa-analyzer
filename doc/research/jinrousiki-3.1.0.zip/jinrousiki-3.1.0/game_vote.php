<?php
require_once('init.php');
Loader::LoadFile('game_vote_class');
GameVote::Execute();
