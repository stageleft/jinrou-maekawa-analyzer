<?php
require_once('init.php');
Loader::LoadFile('admin_class');
JinrouAdmin::DeleteRoom();
