<?php
require_once('init.php');
Loader::LoadFile('role_test_class');
RoleTest::Execute();
