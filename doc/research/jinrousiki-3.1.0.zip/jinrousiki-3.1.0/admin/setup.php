<?php
require_once('init.php');
Loader::LoadFile('setup_class');
JinrouSetup::Execute();
