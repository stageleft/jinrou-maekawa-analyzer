<?php
require_once('init.php');
Loader::LoadFile('icon_message', 'admin_class');
JinrouAdmin::DeleteIcon();
