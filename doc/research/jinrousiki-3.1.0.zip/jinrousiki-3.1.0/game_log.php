<?php
require_once('init.php');
Loader::LoadFile('game_log_class');
GameLog::Execute();
