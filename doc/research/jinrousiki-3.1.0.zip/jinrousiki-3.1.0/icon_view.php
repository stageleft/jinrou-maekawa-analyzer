<?php
require_once('init.php');
Loader::LoadFile('icon_view_class');
IconView::Execute();
