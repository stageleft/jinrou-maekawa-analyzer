<?php
require_once('init.php');
Loader::LoadFile('game_play_class');
GamePlay::Execute();
