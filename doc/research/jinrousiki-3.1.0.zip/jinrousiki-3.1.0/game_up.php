<?php
require_once('init.php');
Loader::LoadFile('game_up_class');
GameUp::Execute();
